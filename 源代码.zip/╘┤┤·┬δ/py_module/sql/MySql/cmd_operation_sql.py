# -*- coding: utf-8 -*-
import pymysql
import py_module.sql.MySql.config as config

host = config.host
port = config.port
user = config.user
password = config.password


class SqlCmd:
    @staticmethod
    def __init__(database_name=""):
        try:
            if database_name == "":
                conn = pymysql.connect(host=host, port=port, user=user, passwd=password)
                print("数据库连接成功,版本:%s" % conn.get_server_info())
            else:
                conn = pymysql.connect(host=host, port=port, user=user, passwd=password, db=database_name)
                print("MySql.%s数据库连接成功,版本:%s" % (database_name, conn.get_server_info()))
        except Exception as e:
            print("数据库错误:%s" % e)

    @staticmethod
    def command(command, database_name="", line=False, autocommit=True, return_data_line=""):
        if database_name == "":
            conn = pymysql.connect(host=host,
                                   port=port, user=user,
                                   passwd=password,
                                   autocommit=autocommit)
        else:
            conn = pymysql.connect(host=host,
                                   port=port, user=user,
                                   passwd=password,
                                   db=database_name,
                                   autocommit=autocommit)
        cursor = conn.cursor()
        sql = command
        cursor.execute(sql)
        if return_data_line:
            return_data = cursor.fetchmany(int(return_data_line))
        else:
            return_data = cursor.fetchall()
        if line:
            try:
                return "影响的行数: %s" % cursor.rowcount
            finally:
                pass
        cursor.close()
        conn.close()
        return return_data

    @staticmethod
    def sql_quit(conn, cursor):
        try:
            cursor.close()
            conn.close()
        except Exception as e:
            print("数据库退出出错：%s" % e)


if __name__ == "__main__":
    SqlCmd()
