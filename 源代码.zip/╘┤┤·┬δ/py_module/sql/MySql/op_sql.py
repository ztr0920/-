from py_module.sql.MySql.cmd_operation_sql import SqlCmd
from loguru import logger


class OpSql:
    @staticmethod
    def __init__(database_name=""):
        SqlCmd(database_name=database_name)

    @staticmethod
    def create_database(database_name, coding="UTF8"):
        try:
            command = "CREATE DATABASE %s CHARACTER SET %s;" % (database_name, coding)
            SqlCmd.command(command=command)
            logger.info("数据库创建成功，命令：\"%s\"" % command)
        except Exception as e:
            logger.error("数据库创建出错：%s" % e)

    @staticmethod
    def delete_database(database_name):
        try:
            command = "DROP DATABASE %s;" % database_name
            SqlCmd.command(command=command)
            logger.info("数据库删除成功，命令：\"%s\"" % command)
        except Exception as e:
            logger.error("数据库删除出错：%s" % e)

    @staticmethod
    def test_database(database_name):
        try:
            database_name_1 = (database_name,)
            show = SqlCmd.command(command="SHOW DATABASES;")
            if database_name_1 not in show:
                OpSql.create_database(database_name=database_name)
                logger.info("数据库%s不存在，已创建！信息如上" % database_name)
            else:
                logger.info("数据库%s存在！" % database_name)
            return show
        except Exception as e:
            logger.error("数据库检测出错：%s" % e)

    @staticmethod
    def create_table(database_name, command, table_name=""):
        try:
            if table_name:
                command_1 = "DROP TABLE IF EXISTS %s;" % table_name
                SqlCmd.command(command=command_1, database_name=database_name)
            SqlCmd.command(command=command, database_name=database_name)
            logger.info("数据表创建成功，命令：\"%s\"" % command)
        except Exception as e:
            logger.error("数据表创建出错：%s" % e)

    @staticmethod
    def delete_table(database_name, table_name):
        try:
            command = "DROP TABLE %s;" % table_name
            SqlCmd.command(command=command, database_name=database_name)
            logger.info("数据库删除成功，命令：\"%s\"" % command)
        except Exception as e:
            logger.error("数据表删除出错：%s" % e)
            logger.error("数据表删除出错指令" + "DROP TABLE %s;" % table_name)

    @staticmethod
    def test_table(database_name, table_name, command="", return_tf=False):
        try:
            if return_tf:
                table_name_1 = (table_name,)
                show = SqlCmd.command(command="SHOW TABLES;", database_name=database_name)
                if table_name_1 not in show:
                    return False
                else:
                    return True
            else:
                table_name_1 = (table_name,)
                show = SqlCmd.command(command="SHOW TABLES;", database_name=database_name)
                if table_name_1 not in show:
                    OpSql.create_table(database_name=database_name, command=command)
                    logger.info("数据表%s不存在，已创建！信息如上" % table_name)
                else:
                    logger.info("数据表%s存在！" % table_name)
                return show
        except Exception as e:
            logger.error("数据表检测出错：%s" % e)

    @staticmethod
    def insert_into(table_name, database_name, field, value):
        try:
            command = "INSERT INTO %s ( %s )VALUES( %s );" % (table_name, field, value)
            SqlCmd.command(command=command, database_name=database_name)
            logger.info("数据插入成功， 命令：%s" % command)
        except Exception as e:
            logger.error("数据插入出错：%s" % e)
            logger.error("数据插入出错指令：%s" % "INSERT INTO %s ( %s )VALUES( %s );" % (table_name, field, value))

    @staticmethod
    def table_info(database_name, table_name):
        try:
            table_info = SqlCmd.command(command="DESC %s ;" % table_name, database_name=database_name)
            table_info_1 = ""
            for x in range(0, len(table_info)):
                table_info_1 = table_info_1 + str(table_info[x]) + "\n"
            return table_info_1
        except Exception as e:
            logger.error("数据表相关信息查询出错：%s" % e)
            logger.error("数据表相关信息查询出错指令：%s" % "DESC %s ;" % table_name)

    @staticmethod
    def table_content(database_name, table_name, where="", use_tuple=False):
        try:
            if where:
                table_content = SqlCmd.command(command="select * from %s WHERE %s;" % (table_name, where),
                                               database_name=database_name)
            else:
                table_content = SqlCmd.command(command="select * from %s;" % table_name, database_name=database_name)
            if use_tuple:
                return table_content
            else:
                table_content_1 = ""
                for x in range(0, len(table_content)):
                    table_content_1 = table_content_1 + str(table_content[x]) + "\n"
                return str(table_content_1)

        except Exception as e:
            if where:
                table_content = "select * from %s WHERE %s;" % (table_name, where)
            else:
                table_content = "select * from %s;" % table_name
            logger.error("数据表内容查询出错：%s" % e)
            logger.error("数据表内容查询出错指令：%s" % table_content)


if __name__ == "__main__":
    table_name_2 = "form"
    database_name_2 = "form_q"
    field_1 = "id, type, question, option1, option2, option3, option4, option5, option6, option7, option8, option9"
    value_1 = "8, 'radio', '听歌时你会分心吗？', '不会', '偶尔', '经常', null, null, null, null, null, null"
    OpSql.insert_into(table_name=table_name_2, database_name=database_name_2, field=field_1, value=value_1)
