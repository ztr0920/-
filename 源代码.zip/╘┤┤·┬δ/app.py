from flask import Flask, request, render_template, session
from py_module.sql.MySql.op_sql import OpSql
from loguru import logger
import uuid
import os
import sys

if getattr(sys, 'frozen', False):
    ROOT_PATH = os.path.dirname(sys.executable)
elif __file__:
    ROOT_PATH = os.path.dirname(__file__)

# logging.basicConfig(level = logging.INFO,format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger.add('.\\log\\log_{time}.log', rotation="0:00", compression="zip")

app = Flask(__name__, template_folder=ROOT_PATH + os.sep + 'templates')
app.config["SECRET_KEY"] = "the_secret_is_810911_OK?!@#$%^&*()_+~@*%^$@#$&%$$R#^^&T(T$%$#*~$^HaHa!"
app.secret_key = "B3sYuf9QNLXkE#n2K84so7vr35WsN#x5lG3AO6PC9f$o0aI27h0yIP3peOc8BjlM"


@app.route("/<string:form>", methods=['GET', 'POST'])
def index(form):
    user_ip = request.environ.get('HTTP_X_REAL_IP', request.remote_addr)
    logger.info("ip为%s的用户访问了%s页。 " % (user_ip, form))
    # 基本参数
    question_database = "form_q"
    question_table = form
    OpSql.test_database(database_name=question_database)
    if request.method == "POST":
        try:
            answer_database = "form_a"
            answer_table = form
            OpSql.test_database(database_name=answer_database)
            command = "CREATE TABLE %s (id BIGINT AUTO_INCREMENT primary key," % answer_table  # !
            OpSql.test_table(database_name=answer_database, table_name=answer_table, command=command)
            question_number = len(OpSql.table_content(database_name=question_database,
                                                      table_name=question_table, use_tuple=True))
            # 前期验证
            if question_number == 0:
                question_number += 1
            for table_generated_data in range(1, question_number + 1):
                command += "a%s VARCHAR(30)," % table_generated_data
            command = command[0:-1] + " )"
            uuid_name = str(uuid.uuid4())
            session["sign_in"] = uuid_name
            OpSql.insert_into(table_name="uuid", field="uuid", value="'" + uuid_name + "'", database_name="uuid")
            # 收集表单信息
            value = ""
            for question_number_th in range(1, question_number + 1):
                one = request.form.get("q" + str(question_number_th))
                value += "'%s'" % one + ", "
            logger.info("ip为%s的用户提交了表单%s{%s}" % (user_ip, form, value[0:-2]))

            # 提交数据给数据库
            field = ""
            for answer_number in range(1, question_number + 1):
                field += "a%s, " % answer_number
            field = field[0:-2]
            OpSql.insert_into(table_name=answer_table, field=field, value=value[0:-2],
                              database_name=answer_database)
        except Exception as e:
            logger.error('错误!%s' % e)
        finally:
            return render_template("thanks.html")
    else:
        if OpSql.test_table(database_name=question_database, table_name=question_table, return_tf=True):
            if OpSql.table_content(database_name="uuid",
                                   table_name="uuid",
                                   where="uuid='%s'" % str(session.get(key='sign_in'))) == '':
                try:
                    # 根据数据表生成表单
                    question_data_tuple = list(OpSql.table_content(database_name=question_database,
                                                                   table_name=question_table, use_tuple=True))
                    question_data_list = []
                    for question_data_number in range(0, len(question_data_tuple)):
                        x = list(question_data_tuple[question_data_number])
                        x[0] = "%s" % str(x[0])
                        # 过滤“None”
                        for value in range(len(x)):
                            if x[value] is None or x[value] == "":
                                x[value:len(x)] = []
                                break
                        question_data_list.append(x)
                    return render_template('网页.html', lists=question_data_list, title="问卷调查-%s" % form)
                except Exception as e:
                    logger.error(e)
                    return render_template("500.html")
            return render_template("thanks.html")
        else:
            return render_template("404.html")


@app.route("/")
def home_page():
    logger.info("ip为%s的用户访问了主页。 " % (request.environ.get('HTTP_X_REAL_IP', request.remote_addr)))
    return render_template("home_page.html", title="主页")


@app.route("/wm")
def wm():
    logger.info("ip为%s的用户访问了关于我们的页面。 " % (request.environ.get('HTTP_X_REAL_IP', request.remote_addr)))
    return render_template("关于我们.html")


@app.errorhandler(404)
def http_status_404(exp):
    logger.warning("ip为%s的用户访问了未存在的地址,转跳到了404页。 " % (request.environ.get('HTTP_X_REAL_IP', request.remote_addr)))
    return render_template("404.html")


@app.errorhandler(500)
def http_status_500(exp):
    logger.exception("ip为%s的用户访问导致500！ " % (request.environ.get('HTTP_X_REAL_IP', request.remote_addr)))
    logger.error(exp)
    return render_template("500.html")


@app.errorhandler(Exception)
def http_status_500_exp(exp):
    logger.exception("ip为%s的用户访问导致500！ " % (request.environ.get('HTTP_X_REAL_IP', request.remote_addr)))
    logger.error(exp)
    return render_template("500.html")


if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1')
